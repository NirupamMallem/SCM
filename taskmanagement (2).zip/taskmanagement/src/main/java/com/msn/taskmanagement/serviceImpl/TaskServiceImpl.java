package com.msn.taskmanagement.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.msn.taskmanagement.entity.Task;
import com.msn.taskmanagement.entity.Users;
import com.msn.taskmanagement.exception.APIException;
import com.msn.taskmanagement.exception.TaskNotFound;
import com.msn.taskmanagement.exception.UserNotFound;
import com.msn.taskmanagement.payload.TaskDto;
import com.msn.taskmanagement.repository.TaskRepository;
import com.msn.taskmanagement.repository.UserRepository;
import com.msn.taskmanagement.service.TaskService;

@Service
public class TaskServiceImpl implements TaskService 
{
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private TaskRepository taskRepository;

	@Override
	public TaskDto saveTask(long userid, TaskDto taskDto) {
	// First check if the user is existing or not by using userRepository method
	Users user = 	userRepository.findById(userid).orElseThrow(
			()-> new UserNotFound(String.format("UserID %d Not Found",userid))
			);
	Task task = modelMapper.map(taskDto, Task.class);
	//after setting the user we r stroing the data in db
	task.setUsers(user);
	Task savedTask = taskRepository.save(task);
	return modelMapper.map(savedTask, TaskDto.class);
	
	}

	@Override
	public List<TaskDto> getAllTasks(long userid) {
	    // First check if the user exists
	    userRepository.findById(userid).orElseThrow(
	        () -> new UserNotFound(String.format("UserID %d Not Found", userid))
	    );
	    
	    // Retrieve tasks associated with the user
	    List<Task> tasks = taskRepository.findAllByUsersId(userid);
	    
	    // Correct mapping of each task to TaskDto
	    return tasks.stream()
	                .map(task -> modelMapper.map(task, TaskDto.class))
	                .collect(Collectors.toList());
	}

	@Override
	public TaskDto getTask(long userid, long todoid) {
		Users users =  userRepository.findById(userid).orElseThrow(
			        () -> new UserNotFound(String.format("UserID %d Not Found", userid))
			    );
		 Task task = taskRepository.findById(todoid).orElseThrow(
				 
				 ()-> new TaskNotFound(String.format("TaskID %d Not Found", todoid))
				 );		
		 if(users.getId()!=task.getUsers().getId())
		 {
			 throw new APIException(String.format("Task id %d does not belong to user id %d",todoid, userid ));
		 }
		 
		 
		 return modelMapper.map(task, TaskDto.class);
	}
   
}
