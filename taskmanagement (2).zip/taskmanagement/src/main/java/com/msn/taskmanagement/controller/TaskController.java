package com.msn.taskmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msn.taskmanagement.payload.TaskDto;
import com.msn.taskmanagement.service.TaskService;

@RestController
@RequestMapping("/api")
public class TaskController 
{  
	@Autowired
	private TaskService taskSerive;
	
   //save the task
	@PostMapping("/{userid}/tasks")
	public ResponseEntity<TaskDto> saveTask(@PathVariable(name="userid") long userId,@RequestBody TaskDto taskDto)
	{
		return new ResponseEntity<>(taskSerive.saveTask(userId, taskDto),HttpStatus.CREATED);
	}
	
	//get all the tasks
	@GetMapping("/{userid}/tasks")
	public ResponseEntity<List<TaskDto>> getAllTasks(
			@PathVariable(name="userid") long userid)
	{
		return new ResponseEntity<>(taskSerive.getAllTasks(userid),HttpStatus.OK);
	}

@GetMapping("/{userid}/tasks/{taskid}")
	public ResponseEntity<TaskDto> getTask(
			
		@PathVariable(name="userid")long userid, @PathVariable(name="taskid") long taskid)
	{
		return new ResponseEntity<>(taskSerive.getTask(userid, taskid),HttpStatus.OK);
	}
	
	//delete individual tasks
}
