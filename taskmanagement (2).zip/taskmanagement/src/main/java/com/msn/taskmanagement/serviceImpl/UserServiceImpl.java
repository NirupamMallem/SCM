package com.msn.taskmanagement.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.msn.taskmanagement.entity.Users;
import com.msn.taskmanagement.payload.UserDto;
import com.msn.taskmanagement.repository.UserRepository;
import com.msn.taskmanagement.service.UserService;

@Service
public class UserServiceImpl implements UserService 
{
	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDto createUser(UserDto userdto) 
	{
		
		Users user = userDtoToUsers(userdto);
		Users savedUser = userRepository.save(user);
		UserDto userDto = usersToUserDto(savedUser);
		return userDto;
		// UserDto and User entity are diff. 
		//if we write the line - userRepository.save(userdto); 
		//it shows error. Because we created User Repository in order to
		//perform operations on user object. bute in the below line we are sending userdto object which is incorect. 
		// so, we need to do some typecasting.
		
	}
  
	private Users userDtoToUsers(UserDto userdto)
	{
		Users users = new Users();
		users.setName(userdto.getName());
		users.setEmail((userdto.getEmail()));
		users.setPassword(userdto.getPassword());
		return users;
		
	}
	
	private UserDto usersToUserDto(Users savedUser)
	{
		UserDto userDto = new UserDto();
		userDto.setEmail(savedUser.getEmail());
		userDto.setName(savedUser.getName());
		userDto.setPassword(savedUser.getPassword());
		return userDto;
		
		
	}
	
}
