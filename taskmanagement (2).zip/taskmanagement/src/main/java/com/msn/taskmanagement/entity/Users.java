package com.msn.taskmanagement.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@Table(name="users",uniqueConstraints = {@UniqueConstraint(columnNames = {"email"})})
public class Users {


	public Users()
	{
		
	}
public Users(long id, String name, String password, String email) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.email = email;
	}

@Override
public String toString() {
	return "Users [id=" + id + ", name=" + name + ", password=" + password + ", email=" + email + "]";
}

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private long id;

@Column(name="name",nullable=false)
private String name;

@Column(name="password",nullable=false)
private String password;

@Column(name="email",nullable=false)
private String email;

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}
  
}
