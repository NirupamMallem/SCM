package com.msn.taskmanagement.service;

import java.util.List;

import com.msn.taskmanagement.payload.TaskDto;

public interface TaskService 
{
	public TaskDto saveTask(long userid, TaskDto taskDto); //accepts path param, object of todo
	
 public List<TaskDto> getAllTasks(long userid);
 public TaskDto getTask(long userid, long todoid);
}
