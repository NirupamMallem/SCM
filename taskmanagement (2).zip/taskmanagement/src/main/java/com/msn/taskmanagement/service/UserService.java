package com.msn.taskmanagement.service;

import com.msn.taskmanagement.payload.UserDto;

public interface UserService 
{
  public UserDto createUser(UserDto userdto);  //return the object saved.
}
