package com.msn.taskmanagement;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TaskmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskmanagementApplication.class, args);
	}
	
	@Bean
	public ModelMapper modelMapper()
	{
		return new ModelMapper();
	}

}

// we create DTO classes in order to not to disturb/use entity classes (when we have additional one to many or many to one configurations)to send/receive data
// we do not use entity in the requestbody.
//
//create user, login existing user, store a task to user, 
//get all task of user, get specific task of user, delete specific task of user